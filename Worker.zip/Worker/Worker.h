#ifndef WORKER_H
#define WORKER_H

#include<string>
#include<cstdio>
#include<iostream>
using namespace std;

class Worker
{
 public:
   Worker();
   Worker(string, int, string, int);
   double compute_pay() const;
   string getName() const;
   int getCompID() const;
   string getDepartment() const;
   int getSocialSecurityNumber() const;
 private:
   string name;
   int compid;
   string dept;
   int ssnum;
};
       
#endif
