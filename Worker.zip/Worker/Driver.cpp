#include "Worker.h"
#include <iostream>
using namespace std;

int main()
{
  Worker         w("Walter", 70113, "sales", 123456789);
  
  cout << w.getName() << " made " << w.compute_pay() << endl;
  cout << endl;

  system("pause");
  return 0;    
    
    
}    
